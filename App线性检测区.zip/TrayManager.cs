using System;
using System.Windows;
using System.Windows.Threading;
using Hardcodet.Wpf.TaskbarNotification;
using System.Windows.Controls;
using System.IO;
using System.Runtime.InteropServices;

namespace WallpaperTool
{
    public class TrayManager : IDisposable
    {
        private TaskbarIcon? _notifyIcon;
        private readonly MainWindow _mainWindow;
        private TrayDropWindow? _dropWindow;
        private DispatcherTimer _monitorTimer;
        private DetectionZoneWindow? _detectionZoneWindow;
        private Point _lastCursorPos;

        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out POINT lpPoint);

        [DllImport("user32.dll")]
        private static extern short GetKeyState(int nVirtKey);

        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        private const int VK_LBUTTON = 0x01;

        private DateTime _lastClickTime;
        private Point _lastClickPos;
        private bool _isClickHandling;
        private const double DoubleClickTimeThreshold = 500; // 双击时间阈值（毫秒）
        private const double ClickMovementThreshold = 5; // 允许的点击位置偏移量
        private const double DragThreshold = 50; // 拖拽判定阈值
        private const double ClickThreshold = 5; // 点击判定阈值

        private bool _isMonitoringActive;
        private Rect _monitoringArea;
        private const double MONITOR_INTERVAL_INACTIVE = 500; // 非活动状态检查间隔(ms)
        private const double MONITOR_INTERVAL_ACTIVE = 16;   // 活动状态检查间隔(ms)
        private const double DETECTION_ZONE_HEIGHT = 10;     // 线性检测区高度

        public TrayManager(MainWindow mainWindow)
        {
            _mainWindow = mainWindow;
            InitializeNotifyIcon();
            InitializeDropWindow();
            InitializeMonitor();
            UpdateDropWindowPosition(); // 启动时更新透明窗口位置
        }

        private void InitializeNotifyIcon()
        {
            _notifyIcon = new TaskbarIcon
            {
                Icon = System.Drawing.SystemIcons.Application,
                ToolTipText = "壁纸设置工具 - 拖放文件到这里",
                Visibility = Visibility.Visible
            };

            // 创建上下文菜单
            var contextMenu = new ContextMenu();

            var showItem = new MenuItem { Header = "显示主窗口" };
            showItem.Click += (s, e) => _mainWindow.Show();

            var hideItem = new MenuItem { Header = "隐藏主窗口" };
            hideItem.Click += (s, e) => _mainWindow.Hide();

            var exitItem = new MenuItem { Header = "退出" };
            exitItem.Click += (s, e) => Application.Current.Shutdown();

            contextMenu.Items.Add(showItem);
            contextMenu.Items.Add(hideItem);
            contextMenu.Items.Add(new Separator());
            contextMenu.Items.Add(exitItem);

            _notifyIcon.ContextMenu = contextMenu;

            // 显示气泡提示
            _notifyIcon.ShowBalloonTip("壁纸设置工具", "已启动，可以拖放文件到图标处", BalloonIcon.Info);
        }

        private void InitializeDropWindow()
        {
            _dropWindow = new TrayDropWindow();
            _dropWindow.Hide(); // 确保窗口在启动时不可见
            _dropWindow.FileDropped += OnFileDropped;
            
            // 初始化检测区窗口
            _detectionZoneWindow = new DetectionZoneWindow();
            _detectionZoneWindow.Hide(); // 初始时隐藏
        }

        private void InitializeMonitor()
        {
            _monitorTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(MONITOR_INTERVAL_INACTIVE)
            };

            _monitorTimer.Tick += MonitorTimer_Tick;
            _monitorTimer.Start();

            // 初始化监控区域
            UpdateMonitorArea();
            _mainWindow.AddLog("托盘监控已启动(低频模式)");
        }

        private void UpdateMonitorArea()
        {
            var trayRect = GetTrayIconRect();
            // 创建一个位于托盘区顶部的线性检测区
            _monitoringArea = new Rect(
                trayRect.X - 50,  // 向左扩展50像素
                trayRect.Y - DETECTION_ZONE_HEIGHT,  // 在托盘区上方创建检测区
                trayRect.Width + 100,  // 向右扩展100像素
                DETECTION_ZONE_HEIGHT  // 使用固定的检测区高度
            );
            
            // 更新检测区窗口位置和大小
            _detectionZoneWindow.Left = _monitoringArea.X;
            _detectionZoneWindow.Top = _monitoringArea.Y;
            _detectionZoneWindow.Width = _monitoringArea.Width;
            _detectionZoneWindow.Height = _monitoringArea.Height;
            
            // 显示检测区窗口
            if (!_detectionZoneWindow.IsVisible)
            {
                _detectionZoneWindow.Show();
                _mainWindow.AddLog($"显示检测区窗口: X={_monitoringArea.X}, Y={_monitoringArea.Y}, W={_monitoringArea.Width}, H={_monitoringArea.Height}");
            }
        }

        private void MonitorTimer_Tick(object sender, EventArgs e)
        {
            if (GetCursorPos(out POINT cursorPos))
            {
                var currentPos = new Point(cursorPos.X, cursorPos.Y);
                bool isInDetectionZone = _monitoringArea.Contains(currentPos);

                // 检测鼠标移动方向
                double verticalMovement = 0;
                if (_lastCursorPos.X != 0 || _lastCursorPos.Y != 0)  // 避免初始值造成错误的移动计算
                {
                    verticalMovement = currentPos.Y - _lastCursorPos.Y;
                    
                    // 记录每次较大的垂直移动以便调试
                    if (Math.Abs(verticalMovement) > 2)
                    {
                        _mainWindow.AddLog($"鼠标垂直移动: {verticalMovement:F2}, 位置: ({currentPos.X:F0},{currentPos.Y:F0})");
                    }
                }
                _lastCursorPos = currentPos;

                // 根据鼠标是否在检测区内调整计时器频率
                if (isInDetectionZone != _isMonitoringActive)
                {
                    _isMonitoringActive = isInDetectionZone;
                    _monitorTimer.Interval = TimeSpan.FromMilliseconds(
                        isInDetectionZone ? MONITOR_INTERVAL_ACTIVE : MONITOR_INTERVAL_INACTIVE
                    );
                    _mainWindow.AddLog($"切换到{(isInDetectionZone ? "高" : "低")}频模式, 当前位置: ({currentPos.X:F0},{currentPos.Y:F0})");
                }
                
                // 只在检测区内处理拖放逻辑
                if (isInDetectionZone)
                {
                    short keyState = GetKeyState(VK_LBUTTON);
                    bool isLeftButtonDown = (keyState & 0x8000) != 0;
                    
                    if (isLeftButtonDown)
                    {
                        // 判断垂直移动方向
                        if (verticalMovement > 1) // 从上往下移动（大于阈值以过滤微小抖动）
                        {
                            _mainWindow.AddLog($"检测到向下移动: {verticalMovement:F2}，显示窗口");
                            var trayRect = GetTrayIconRect();
                            ShowDropWindow(trayRect);
                        }
                        else if (verticalMovement < -1) // 从下往上移动（小于阈值以过滤微小抖动）
                        {
                            _mainWindow.AddLog($"检测到向上移动: {verticalMovement:F2}，隐藏窗口");
                            _dropWindow?.Hide();
                        }
                    }
                    else
                    {
                        _dropWindow?.Hide();
                    }
                }
                else
                {
                    // 不在检测区内，根据情况隐藏窗口
                    _dropWindow?.Hide();
                }
            }
        }

        private bool HandleTrayIconClick(Point currentPos, bool isLeftButtonDown)
        {
            var trayRect = GetTrayIconRect();
            bool isInTrayArea = IsPointNearRect(currentPos, trayRect);

            if (isLeftButtonDown)
            {
                if (!_isClickHandling)
                {
                    _isClickHandling = true;
                    _lastClickPos = currentPos;
                    _lastClickTime = DateTime.Now;
                    return true;
                }
                else
                {
                    var distance = Math.Sqrt(
                        Math.Pow(currentPos.X - _lastClickPos.X, 2) +
                        Math.Pow(currentPos.Y - _lastClickPos.Y, 2));

                    if (isInTrayArea)
                    {
                        // 在托盘区域内移动，不显示窗口
                        return true;
                    }
                    else
                    {
                        // 在托盘区域外移动，允许显示窗口
                        _isClickHandling = false;
                        return false;
                    }
                }
            }
            else
            {
                if (_isClickHandling)
                {
                    var distance = Math.Sqrt(
                        Math.Pow(currentPos.X - _lastClickPos.X, 2) +
                        Math.Pow(currentPos.Y - _lastClickPos.Y, 2));

                    if (distance <= ClickThreshold && isInTrayArea)
                    {
                        var timeSinceLastClick = (DateTime.Now - _lastClickTime).TotalMilliseconds;
                        if (timeSinceLastClick <= DoubleClickTimeThreshold)
                        {
                            OnDoubleClick();
                        }
                        else
                        {
                            OnSingleClick();
                        }
                    }
                    _isClickHandling = false;
                }
            }

            return false;
        }

        private void OnSingleClick()
        {
            _mainWindow.AddLog("托盘图标单击");
            // 添加单击处理逻辑
        }

        private void OnDoubleClick()
        {
            _mainWindow.AddLog("托盘图标双击");
            _mainWindow.Show(); // 显示主窗口
        }

        private bool IsPointNearRect(Point point, Rect rect)
        {
            // 扩大检测区域
            var expandedRect = new Rect(
                rect.X - 20,
                rect.Y - 20,
                rect.Width + 40,
                rect.Height + 40
            );

            return expandedRect.Contains(point);
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct APPBARDATA
        {
            public int cbSize;
            public IntPtr hWnd;
            public int uCallbackMessage;
            public int uEdge;
            public RECT rc;
            public IntPtr lParam;
        }

        [DllImport("shell32.dll")]
        private static extern IntPtr SHAppBarMessage(uint dwMessage, ref APPBARDATA pData);

        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

        private Rect GetTrayIconRect()
        {
            try
            {
                // 找到任务栏
                IntPtr taskBar = FindWindow("Shell_TrayWnd", null);
                if (taskBar != IntPtr.Zero)
                {
                    // 找到通知区域
                    IntPtr trayNotify = FindWindowEx(taskBar, IntPtr.Zero, "TrayNotifyWnd", null);
                    if (trayNotify != IntPtr.Zero)
                    {
                        // 获取通知区域位置
                        RECT trayRect;
                        if (GetWindowRect(trayNotify, out trayRect))
                        {
                            // 获取屏幕工作区
                            var workArea = SystemParameters.WorkArea;

                            // 计算托盘图标的预期位置
                            double iconX = trayRect.Left;
                            double iconY = trayRect.Top;
                            double iconWidth = trayRect.Right - trayRect.Left;
                            double iconHeight = trayRect.Bottom - trayRect.Top;

                            _mainWindow.AddLog($"通知区域位置: Left={trayRect.Left}, Top={trayRect.Top}, Right={trayRect.Right}, Bottom={trayRect.Bottom}");

                            return new Rect(iconX, iconY, iconWidth, iconHeight);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _mainWindow.AddLog($"获取托盘位置错误: {ex.Message}");
            }

            // 如果无法获取准确位置，使用默认位置
            var screen = SystemParameters.WorkArea;
            return new Rect(
                screen.Right - 200,
                screen.Bottom - 40,
                32,
                32
            );
        }

        private void ShowDropWindow(Rect trayRect)
        {
            if (_dropWindow != null && !_dropWindow.IsVisible)
            {
                _dropWindow.Left = trayRect.X;
                _dropWindow.Top = trayRect.Y;
                _dropWindow.Width = trayRect.Width;
                _dropWindow.Height = trayRect.Height;

                _mainWindow.AddLog($"显示拖放窗口: X={_dropWindow.Left}, Y={_dropWindow.Top}, W={_dropWindow.Width}, H={_dropWindow.Height}");

                _dropWindow.Show();
                _dropWindow.Activate();
            }
        }

        public void UpdateDropWindowPosition()
        {
            UpdateMonitorArea(); // 更新监控区域
            var trayRect = GetTrayIconRect();
            // 仅更新位置，不显示窗口
            _dropWindow.Left = trayRect.X;
            _dropWindow.Top = trayRect.Y;
            _dropWindow.Width = trayRect.Width;
            _dropWindow.Height = trayRect.Height;
        }

        private void OnFileDropped(string[] files)
        {
            foreach (string file in files)
            {
                string extension = Path.GetExtension(file).ToLowerInvariant();
                _mainWindow.AddLog($"收到文件: {file}");
                _mainWindow.AddLog($"文件格式: {extension}");
                _mainWindow.AddLog("------------------------");

                // 如果窗口是隐藏的，显示窗口
                if (!_mainWindow.IsVisible)
                {
                    _mainWindow.Show();
                }
            }

            // 显示通知
            _notifyIcon?.ShowBalloonTip(
                "收到文件",
                $"成功接收 {files.Length} 个文件",
                BalloonIcon.Info);
        }

        public void Dispose()
        {
            _monitorTimer?.Stop();
            _notifyIcon?.Dispose();
            _dropWindow?.Close();
            _detectionZoneWindow?.Close();
        }
    }

    // 检测区可视化窗口
    public class DetectionZoneWindow : Window
    {
        public DetectionZoneWindow()
        {
            // 设置窗口样式
            WindowStyle = WindowStyle.None;
            ResizeMode = ResizeMode.NoResize;
            ShowInTaskbar = false;
            Topmost = true;
            AllowsTransparency = true;
            Background = System.Windows.Media.Brushes.Transparent;
            
            // 创建内容
            var grid = new Grid();
            var border = new Border
            {
                Background = new System.Windows.Media.SolidColorBrush(
                    System.Windows.Media.Color.FromArgb(100, 255, 0, 0)), // 半透明红色，更明显
                BorderBrush = System.Windows.Media.Brushes.Red,
                BorderThickness = new Thickness(1)
            };
            grid.Children.Add(border);
            Content = grid;
            
            // 确保窗口不获取焦点且允许点击穿透
            Focusable = false;
        }
        
        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            
            // 设置窗口为点击穿透
            var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            var extendedStyle = Win32.GetWindowLong(hwnd, Win32.GWL_EXSTYLE);
            Win32.SetWindowLong(hwnd, Win32.GWL_EXSTYLE, extendedStyle | Win32.WS_EX_TRANSPARENT);
        }
    }
    
    // Win32 API 辅助类
    public static class Win32
    {
        public const int GWL_EXSTYLE = -20;
        public const int WS_EX_TRANSPARENT = 0x00000020;
        
        [DllImport("user32.dll")]
        public static extern int GetWindowLong(IntPtr hwnd, int index);
        
        [DllImport("user32.dll")]
        public static extern int SetWindowLong(IntPtr hwnd, int index, int newStyle);
    }
}